# meta-qoriq-demos
Supplemental Yocto layer to hold pending patches to be upstreamed.
