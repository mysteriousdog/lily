.. SPDX-License-Identifier: CC-BY-SA-2.0-UK

==========================================
Yocto Project Profiling and Tracing Manual
==========================================

|

.. toctree::
   :caption: Table of Contents
   :numbered:

   profile-manual-intro
   profile-manual-arch
   profile-manual-usage
   profile-manual-examples
   history

.. include:: /boilerplate.rst
