.. SPDX-License-Identifier: CC-BY-SA-2.0-UK

***********************
Manual Revision History
***********************

.. list-table::
   :widths: 10 15 40
   :header-rows: 1

   * - Revision
     - Date
     - Note
   * - 3.2
     - October 2020
     - The initial document released with the Yocto Project 3.2 Release
