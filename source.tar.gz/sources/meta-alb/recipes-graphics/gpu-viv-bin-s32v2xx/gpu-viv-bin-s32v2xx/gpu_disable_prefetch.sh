#!/bin/sh
# Copyright 2019 NXP

export GPU_VIV_EXT_RESOLVE=0
