# Copyright 2018 NXP
#!/bin/sh

export FB_MULTI_BUFFER=2
