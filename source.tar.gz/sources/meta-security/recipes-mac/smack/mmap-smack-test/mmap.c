#include <stdio.h>

int main(int argc, char **argv)
{
    printf("Original test program removed while investigating its license.\n");
    return 1;
}
